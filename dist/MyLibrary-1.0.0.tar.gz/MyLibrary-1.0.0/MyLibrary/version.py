#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021/04/28
# @Author  : yuetao
# @Site    : 
# @File    : version.py
# @Desc    :

VERSION = "1.0.0"
